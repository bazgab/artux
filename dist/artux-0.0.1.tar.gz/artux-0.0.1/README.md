# Artux

A simple real-time CPU Temperature tracker for Linux systems.

## Installation

